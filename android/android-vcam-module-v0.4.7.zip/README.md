# Android virtual-camera processor client v0.4.7

This is the single-camera, physical-provider-safe build for the Apollo phone.
One Camera2 hardware encoder supplies independent transports to Windows slot 0
at `192.168.1.35:10000` and the Arch local processor at
`192.168.1.11:10001`. The selected processor returns video to the phone's SRT
listener on port `10001`.

## Camera topology

- The module creates exactly one loopback node: `/dev/video20`.
- The AOSP external provider exposes that node as external Camera2 ID `120`.
- `/dev/video0`, `/dev/video1`, and every Qualcomm camera node remain unchanged.
- Android init remains the sole owner of the Qualcomm physical-camera provider.
- The module never issues `stop` or `kill` against the Qualcomm provider and
  never mounts over a physical camera device node.

The installable ZIP uses the validated provider, producer, fallback image, and
`v4l2loopback.ko` from v0.3.0. Apollo does not project module files into its
separate read-only vendor partition, so the early hook retains v0.3.0's two
known-good vendor-file binds: the combined IR/external VINTF fragment and the
external-camera implementation. Neither bind touches camera device nodes or
the Qualcomm provider.

At installation only, `customize.sh` repairs the one known stale state from the
experimental dual build: if `persist.vendor.camera.disable` is exactly `1`, it
is changed to `0` before reboot. Other values and all other properties are left
untouched; there is no recurring property override.

## Transport isolation

- `PHONE_CAPTURE_ENABLED=1` runs one `bridge-capture.sh` process and the merged
  app's scoped physical Camera2 owner. Front/back changes stay inside that
  owner and retain the same encoder TCP endpoint and transport workers.
- `bridge-capture.sh` is the only TCP reader of the hardware H.264 encoder. Its
  tee writes complete MPEG-TS copies to raw fallback UDP `10022`, Windows-feed
  UDP `10023`, and Arch-feed UDP `10027`.
- `bridge-sender.sh` consumes only UDP `10023` and owns the Windows SRT caller
  to `192.168.1.35:10000`.
- `bridge-arch-sender.sh` consumes only UDP `10027` and owns the Arch SRT
  caller to `192.168.1.11:10001`.
- The two SRT workers have separate processes, logs, progress files, status
  files, and exponential retry state. A Windows outage cannot restart or
  consume packets from the Arch path, and an Arch outage cannot affect slot 0.
  Their atomic status files are
  `/data/local/tmp/android-vcam-windows-sender.state` and
  `/data/local/tmp/android-vcam-arch-sender.state`.
- `bridge-return.sh` receives processed frames and publishes a decoded-frame
  heartbeat while copying the optional AAC track to a private A/V feed.
- `bridge-audio.sh` decodes that AAC track to 48 kHz mono PCM on localhost
  UDP 10025. The scoped Xposed module consumes it only while the redirected
  front camera is active; it is never played through the phone speaker.
- `bridge-output-selector.sh` is the only writer to Camera2 ID 120. It selects
  processed video only while frames advance. With phone capture disabled, a
  return outage shows the module fallback frame without changing camera
  identity or format; phone-input mode may instead fall back to its raw feed.
- `/data/adb/android-vcam-output.conf` is the durable, atomically replaced
  output policy. Enable/disable, horizontal mirror, and 0/90/180/270-degree
  rotation only replace the FIFO decoder worker. The provider, `/dev/video20`,
  producer, Camera2 ID 120 registration, and already-open camera sessions stay
  alive; disabled output continuously resolves to the producer's placeholder.

Camera2 ID 120 remains 1280×720 at 30 FPS across return-stream loss and
recovery. The unified APK preview selects ID 120 first and falls back only to
another external camera, never to a physical phone camera.

The Arch manager calls the same narrow helper that is also available from the
command line:

```sh
python arch-linux/bin/android_bridge.py configure-output \
  --host 192.168.1.12 --output-enabled true \
  --output-mirror true --output-rotation 90
```

The command is idempotent: repeating an unchanged policy leaves its revision
and decoder worker untouched. Module versions before v0.4.6 do not consume the
control file, so the UI must treat a missing effective revision as pending
rather than claiming that the setting was applied.
