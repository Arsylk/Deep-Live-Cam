# Android virtual-camera processor client v0.4.4

This is the single-camera, physical-provider-safe build for the Apollo phone.
The companion app sends its physical Camera2 feed to the Arch processor at
`192.168.1.11:10001` over SRT. The processed stream returns to the phone's SRT
listener on port `10001`.

## Camera topology

- The module creates exactly one loopback node: `/dev/video20`.
- The AOSP external provider exposes that node as external Camera2 ID `120`.
- `/dev/video0`, `/dev/video1`, and every Qualcomm camera node remain unchanged.
- Android init remains the sole owner of the Qualcomm physical-camera provider.
- The module never issues `stop` or `kill` against the Qualcomm provider and
  never mounts over a physical camera device node.

The installable ZIP uses the validated provider, producer, fallback image, and
`v4l2loopback.ko` from v0.3.0. Apollo does not project module files into its
separate read-only vendor partition, so the early hook retains v0.3.0's two
known-good vendor-file binds: the combined IR/external VINTF fragment and the
external-camera implementation. Neither bind touches camera device nodes or
the Qualcomm provider.

At installation only, `customize.sh` repairs the one known stale state from the
experimental dual build: if `persist.vendor.camera.disable` is exactly `1`, it
is changed to `0` before reboot. Other values and all other properties are left
untouched; there is no recurring property override.

## Transport isolation

- `bridge-capture.sh` is the only client of the app's hardware AVC socket. It
  fans encoded physical frames into local raw and sender feeds.
- `bridge-sender.sh` independently retries the Arch SRT input.
- After the first unlock, the module starts the merged app's physical Camera2
  owner with the persisted front lens. Reboot therefore restores the intended
  phone-front route without a manual Start tap; ordinary camera-busy errors
  stay inside the owner's retry loop.
- `bridge-return.sh` receives processed frames and publishes a decoded-frame
  heartbeat while copying the optional AAC track to a private A/V feed.
- `bridge-audio.sh` decodes that AAC track to 48 kHz mono PCM on localhost
  UDP 10025. The scoped Xposed module consumes it only while the redirected
  front camera is active; it is never played through the phone speaker.
- `bridge-output-selector.sh` is the only writer to Camera2 ID 120. It selects
  processed video only while frames advance, otherwise it displays the same
  phone feed locally without changing camera identity or format.

Camera2 ID 120 remains 1280×720 at 30 FPS across return-stream loss and
recovery. The v0.4.4 APK preview selects ID 120 first and falls back only to
another external camera, never to a physical phone camera.
