#!/system/bin/sh

MODDIR=${0%/*}
. "$MODDIR/bridge.conf"

FFMPEG="$TERMUX_PREFIX/bin/ffmpeg"
export LD_LIBRARY_PATH="$TERMUX_PREFIX/lib"
RETURN_FIFO=/data/local/tmp/android-vcam-return.mjpg
PROGRESS=/data/local/tmp/android-vcam-return.progress
WORKER_PID_FILE=/data/local/tmp/android-vcam-output-worker.pid
DETAIL_LOG=/data/local/tmp/android-vcam-output-ffmpeg.log
current=""
worker_pid=""

stop_worker() {
    [ -n "$worker_pid" ] || return 0
    kill "$worker_pid" 2>/dev/null || true
    wait "$worker_pid" 2>/dev/null || true
    worker_pid=""
    rm -f "$WORKER_PID_FILE"
}

start_worker() {
    source_name=$1
    if [ "$source_name" = "processed" ]; then
        source_port=$ANDROID_PROCESSED_FEED_PORT
    else
        source_port=$ANDROID_RAW_CAMERA_PORT
    fi
    "$FFMPEG" \
        -y -hide_banner -loglevel warning -nostdin \
        -fflags nobuffer -flags low_delay \
        -analyzeduration 0 -probesize 32768 \
        -f mpegts -i "udp://127.0.0.1:$source_port?fifo_size=1000000&overrun_nonfatal=1&reuse=1" \
        -map 0:v:0 -an \
        -vf "scale=$VIDEO_WIDTH:$VIDEO_HEIGHT:flags=fast_bilinear:out_range=full,fps=$VIDEO_FPS" \
        -pix_fmt yuvj420p -c:v mjpeg -q:v 3 -f image2pipe "$RETURN_FIFO" \
        >/dev/null 2>"$DETAIL_LOG" &
    worker_pid=$!
    echo "$worker_pid" >"$WORKER_PID_FILE"
    current=$source_name
    echo "$(date '+%Y-%m-%d %H:%M:%S') Camera2 source -> $current (pid $worker_pid)"
}

processed_is_fresh() {
    [ -s "$PROGRESS" ] || return 1
    modified=$(stat -c %Y "$PROGRESS" 2>/dev/null) || return 1
    now=$(date +%s)
    [ $((now - modified)) -le "$PROCESSED_STALE_SECONDS" ]
}

trap 'stop_worker; exit 0' TERM INT EXIT
start_worker raw
while true; do
    desired=raw
    processed_is_fresh && desired=processed
    if [ "$desired" != "$current" ]; then
        stop_worker
        start_worker "$desired"
    elif [ -z "$worker_pid" ] || ! kill -0 "$worker_pid" 2>/dev/null; then
        stop_worker
        start_worker "$desired"
    fi
    sleep 1
done
