#!/system/bin/sh

MODDIR=${0%/*}
. "$MODDIR/bridge.conf"

FFMPEG="$TERMUX_PREFIX/bin/ffmpeg"
export LD_LIBRARY_PATH="$TERMUX_PREFIX/lib"
DETAIL_LOG=/data/local/tmp/android-vcam-capture-ffmpeg.log
ATTEMPT_LOG=${DETAIL_LOG}.current
retry_delay=1

# This is the only TCP client of dev.vcam.bridge. It fans the already encoded
# phone stream to two loopback-only feeds: one for the Windows sender and one
# for Camera2 ID 120's local raw fallback.
while true; do
    started_at=$(date +%s)
    "$FFMPEG" \
        -hide_banner -loglevel warning -nostdin \
        -fflags +genpts+nobuffer -flags low_delay \
        -use_wallclock_as_timestamps 1 \
        -analyzeduration 0 -probesize 65536 \
        -framerate "$VIDEO_FPS" -f h264 \
        -i "tcp://127.0.0.1:$ANDROID_ENCODER_PORT?timeout=5000000" \
        -map 0:v:0 -an -c:v copy -bsf:v dump_extra=freq=keyframe \
        -f tee \
        "[f=mpegts:mpegts_flags=resend_headers:onfail=ignore]udp://127.0.0.1:$ANDROID_RAW_CAMERA_PORT?pkt_size=1316|[f=mpegts:mpegts_flags=resend_headers:onfail=ignore]udp://127.0.0.1:$ANDROID_SENDER_FEED_PORT?pkt_size=1316" \
        >/dev/null 2>"$ATTEMPT_LOG"
    status=$?
    mv -f "$ATTEMPT_LOG" "$DETAIL_LOG"
    runtime=$(($(date +%s) - started_at))
    echo "$(date '+%Y-%m-%d %H:%M:%S') capture exited status=$status after ${runtime}s; retrying in ${retry_delay}s (details: $DETAIL_LOG)"
    sleep "$retry_delay"
    if [ "$runtime" -ge 30 ]; then
        retry_delay=1
    elif [ "$retry_delay" -lt 10 ]; then
        retry_delay=$((retry_delay * 2))
        [ "$retry_delay" -gt 10 ] && retry_delay=10
    fi
done
