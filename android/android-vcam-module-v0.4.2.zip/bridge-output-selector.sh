#!/system/bin/sh

MODDIR=${0%/*}
. "$MODDIR/bridge.conf"

FFMPEG="$TERMUX_PREFIX/bin/ffmpeg"
export LD_LIBRARY_PATH="$TERMUX_PREFIX/lib"
RETURN_FIFO=/data/local/tmp/android-vcam-return.mjpg
PROGRESS=/data/local/tmp/android-vcam-return.progress
WORKER_PID_FILE=/data/local/tmp/android-vcam-output-worker.pid
DETAIL_LOG=/data/local/tmp/android-vcam-output-ffmpeg.log
current=""
worker_pid=""
last_progress_frame=-1
last_progress_at=0
processed_fresh_since=0

stop_worker() {
    [ -n "$worker_pid" ] || return 0
    stopped_pid=$worker_pid
    kill "$stopped_pid" 2>/dev/null || true
    stop_attempt=0
    while kill -0 "$stopped_pid" 2>/dev/null && [ "$stop_attempt" -lt 10 ]; do
        sleep 0.1
        stop_attempt=$((stop_attempt + 1))
    done
    if kill -0 "$stopped_pid" 2>/dev/null; then
        kill -9 "$stopped_pid" 2>/dev/null || true
    fi
    wait "$stopped_pid" 2>/dev/null || true
    worker_pid=""
    rm -f "$WORKER_PID_FILE"
}

start_worker() {
    source_name=$1
    if [ "$source_name" = "processed" ]; then
        source_port=$ANDROID_PROCESSED_FEED_PORT
    else
        source_port=$ANDROID_RAW_CAMERA_PORT
    fi
    "$FFMPEG" \
        -y -hide_banner -loglevel warning -nostdin \
        -fflags nobuffer -flags low_delay \
        -analyzeduration 0 -probesize 32768 \
        -f mpegts -i "udp://127.0.0.1:$source_port?fifo_size=1000000&overrun_nonfatal=1&reuse=1" \
        -map 0:v:0 -an \
        -vf "scale=$VIDEO_WIDTH:$VIDEO_HEIGHT:flags=fast_bilinear:out_range=full,fps=$VIDEO_FPS" \
        -pix_fmt yuvj420p -c:v mjpeg -q:v 2 -f image2pipe "$RETURN_FIFO" \
        >/dev/null 2>"$DETAIL_LOG" &
    worker_pid=$!
    echo "$worker_pid" >"$WORKER_PID_FILE"
    current=$source_name
    echo "$(date '+%Y-%m-%d %H:%M:%S') Camera2 source -> $current (pid $worker_pid)"
}

processed_is_fresh() {
    if [ ! -s "$PROGRESS" ]; then
        last_progress_frame=-1
        last_progress_at=0
        return 1
    fi
    progress_frame=$(
        tail -n 32 "$PROGRESS" 2>/dev/null | awk -F= '
            $1 == "frame" { value = $2 }
            END {
                gsub(/[[:space:]]/, "", value)
                print value
            }
        '
    )
    case "$progress_frame" in
        ''|*[!0-9]*) return 1 ;;
    esac
    now=$(date +%s)
    if [ "$last_progress_frame" -lt 0 ] || [ "$progress_frame" -lt "$last_progress_frame" ]; then
        # A newly observed/recreated file establishes a baseline only. It is
        # not evidence of live video until a later frame counter advances.
        last_progress_frame=$progress_frame
        last_progress_at=0
    elif [ "$progress_frame" -gt "$last_progress_frame" ]; then
        last_progress_frame=$progress_frame
        last_progress_at=$now
    fi
    [ "$last_progress_at" -gt 0 ] && \
        [ $((now - last_progress_at)) -le "$PROCESSED_STALE_SECONDS" ]
}

trap 'stop_worker; exit 0' TERM INT EXIT
start_worker raw
while true; do
    desired=raw
    if processed_is_fresh; then
        now=$(date +%s)
        if [ "$current" = "processed" ]; then
            desired=processed
        else
            [ "$processed_fresh_since" -gt 0 ] || processed_fresh_since=$now
            if [ $((now - processed_fresh_since)) -ge "$PROCESSED_RECOVERY_SECONDS" ]; then
                desired=processed
            fi
        fi
    else
        processed_fresh_since=0
    fi
    if [ "$desired" != "$current" ]; then
        stop_worker
        start_worker "$desired"
    elif [ -z "$worker_pid" ] || ! kill -0 "$worker_pid" 2>/dev/null; then
        stop_worker
        start_worker "$desired"
    fi
    sleep 0.25
done
