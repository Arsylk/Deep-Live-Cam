#!/system/bin/sh

MODDIR=${0%/*}
LOG=/data/local/tmp/android-vcam.log
PRODUCER_PID_FILE=/data/local/tmp/android-vcam-producer.pid
PROVIDER_PID_FILE=/data/local/tmp/android-vcam-provider.pid
PROVIDER_SUPERVISOR_PID_FILE=/data/local/tmp/android-vcam-provider-supervisor.pid
RETURN_PID_FILE=/data/local/tmp/android-vcam-return.pid
SENDER_PID_FILE=/data/local/tmp/android-vcam-sender.pid
PREVIEW_PID_FILE=/data/local/tmp/android-vcam-preview.pid
VINTF_TARGET=/vendor/etc/vintf/manifest/android.hardware.ir-service.lineage.xml
EXT_IMPL_TARGET=/vendor/lib64/camera.device@3.4-external-impl.so
VCAM_VENDOR="$MODDIR/system/vendor"
RETURN_FIFO=/data/local/tmp/android-vcam-return.mjpg

. "$MODDIR/bridge.conf"

exec >>"$LOG" 2>&1
echo "$(date '+%Y-%m-%d %H:%M:%S') android-vcam service starting"
rm -f "$PRODUCER_PID_FILE" "$PROVIDER_PID_FILE" "$PROVIDER_SUPERVISOR_PID_FILE" \
      "$RETURN_PID_FILE" "$SENDER_PID_FILE" "$PREVIEW_PID_FILE"

# post-fs-data.sh installs this fragment before hwservicemanager starts. A
# late bind would require a disruptive global HAL restart, so fail safely if
# the early hook did not run.
if ! grep -q " $VINTF_TARGET " /proc/mounts; then
    echo "VINTF fragment is not mounted; refusing late HAL registration"
    exit 1
fi
if ! grep -q " $EXT_IMPL_TARGET " /proc/mounts; then
    echo "external-camera config shim is not mounted; refusing HAL registration"
    exit 1
fi

if ! grep -q '^v4l2loopback ' /proc/modules; then
    insmod "$MODDIR/v4l2loopback.ko" \
        video_nr=20 \
        card_label=ProcessedCamera \
        exclusive_caps=0 \
        max_width=1920 \
        max_height=1080 \
        max_buffers=4 \
        max_openers=8
fi

attempt=0
while [ ! -e /dev/video20 ] && [ "$attempt" -lt 50 ]; do
    sleep 0.1
    attempt=$((attempt + 1))
done

if [ ! -e /dev/video20 ]; then
    echo "loopback node /dev/video20 did not appear"
    exit 1
fi

cp "$VCAM_VENDOR/etc/external_camera_config.xml" /data/local/tmp/vcam.xml
chmod 0644 /data/local/tmp/vcam.xml
chcon u:object_r:vendor_configs_file:s0 /data/local/tmp/vcam.xml 2>/dev/null

if [ ! -p "$RETURN_FIFO" ]; then
    rm -f "$RETURN_FIFO"
    mkfifo "$RETURN_FIFO"
fi
chmod 0660 "$RETURN_FIFO"

"$VCAM_VENDOR/bin/vcam_mjpeg_fifo" \
    /dev/video20 \
    "$RETURN_FIFO" \
    "$VCAM_VENDOR/etc/android-vcam/vcam-fallback-1280x720.jpg" \
    "$VIDEO_WIDTH" "$VIDEO_HEIGHT" "$VIDEO_FPS" >>"$LOG" 2>&1 &
echo $! >"$PRODUCER_PID_FILE"

sleep 1

/system/bin/sh "$MODDIR/provider-supervisor.sh" &
echo $! >"$PROVIDER_SUPERVISOR_PID_FILE"

attempt=0
while [ ! -s "$PROVIDER_PID_FILE" ] && [ "$attempt" -lt 50 ]; do
    sleep 0.1
    attempt=$((attempt + 1))
done

if [ "$BRIDGE_ENABLED" = "1" ]; then
    # Termux is in credential-encrypted app storage and is intentionally absent
    # while user 0 is locked after boot. Keep the local camera/provider usable,
    # then wait here until the first unlock makes FFmpeg available.
    wait_count=0
    while [ ! -x "$TERMUX_PREFIX/bin/ffmpeg" ]; do
        if [ $((wait_count % 30)) -eq 0 ]; then
            echo "waiting for user unlock and Termux FFmpeg; camera 120 is on fallback"
        fi
        wait_count=$((wait_count + 1))
        sleep 2
    done

    echo "Termux FFmpeg available; starting Android-Windows bridge"
    if [ "${ARCH_PREVIEW_ENABLED:-0}" = "1" ]; then
        /system/bin/sh "$MODDIR/bridge-preview.sh" >>"$LOG" 2>&1 &
        echo $! >"$PREVIEW_PID_FILE"
    fi
    /system/bin/sh "$MODDIR/bridge-return.sh" >>"$LOG" 2>&1 &
    echo $! >"$RETURN_PID_FILE"
    /system/bin/sh "$MODDIR/bridge-sender.sh" >>"$LOG" 2>&1 &
    echo $! >"$SENDER_PID_FILE"
else
    echo "network bridge disabled; using fallback frame"
fi

echo "$(date '+%Y-%m-%d %H:%M:%S') producer=$(cat "$PRODUCER_PID_FILE") provider=$(cat "$PROVIDER_PID_FILE" 2>/dev/null) provider_supervisor=$(cat "$PROVIDER_SUPERVISOR_PID_FILE" 2>/dev/null) return=$(cat "$RETURN_PID_FILE" 2>/dev/null) sender=$(cat "$SENDER_PID_FILE" 2>/dev/null) preview=$(cat "$PREVIEW_PID_FILE" 2>/dev/null)"
