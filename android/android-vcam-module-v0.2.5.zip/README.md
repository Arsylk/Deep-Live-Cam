# Android processed-camera bridge v0.2.5

This KernelSU module publishes the Windows-processed return as external
Camera2 device 120, while the companion `dev.vcam.bridge` app sends the
phone's physical Camera2 stream to Windows `192.168.1.35`.

The v0.2.5 preview tap also copies the original encoded Windows return to local
UDP 10021, then `bridge-preview.sh` remuxes it to an SRT listener on Arch
`192.168.1.11:10003`. The supervised Arch receiver publishes it through the
same `/dev/video0` and `/dev/video1` devices used for a direct Windows return.
There is no additional H.264 encode and no DroidCam-specific device is needed.
If the Arch receiver is temporarily stopped, only the isolated relay retries;
Camera2 120 continues normally.

Expected mapping:

- Android → Windows: SRT/UDP 10000
- Windows → Android: SRT/UDP 10001
- Android processed preview → Arch: SRT/UDP 10003
- V4L2 backing node: `/dev/video20`
- external Camera2 ID: `120`

Runtime logs and PID files are under `/data/local/tmp/android-vcam-*`. The
external camera provider is supervised independently and is automatically
re-registered if Android kills it under memory pressure.
