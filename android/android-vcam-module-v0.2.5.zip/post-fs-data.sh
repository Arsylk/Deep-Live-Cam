#!/system/bin/sh

MODDIR=${0%/*}
LOG=/data/local/tmp/android-vcam.log
VINTF_SOURCE="$MODDIR/android-vcam-vintf.xml"
VINTF_TARGET=/vendor/etc/vintf/manifest/android.hardware.ir-service.lineage.xml
EXT_IMPL_SOURCE="$MODDIR/camera.device@3.4-external-impl.so"
EXT_IMPL_TARGET=/vendor/lib64/camera.device@3.4-external-impl.so

if [ -f "$LOG" ] && [ "$(wc -c <"$LOG")" -gt 1048576 ]; then
    mv -f "$LOG" "$LOG.1"
fi
exec >>"$LOG" 2>&1
echo "$(date '+%Y-%m-%d %H:%M:%S') android-vcam early VINTF setup"

# Apollo uses a standalone read-only /vendor partition, so KernelSU cannot
# project system/vendor module files into it. Replace one existing fragment
# with a combined fragment before hwservicemanager reads the device manifest.
# The replacement preserves the fragment's original IR declaration.
if ! grep -q " $VINTF_TARGET " /proc/mounts; then
    chcon u:object_r:vendor_configs_file:s0 "$VINTF_SOURCE" 2>/dev/null
    mount --bind "$VINTF_SOURCE" "$VINTF_TARGET"
fi

if grep -q " $VINTF_TARGET " /proc/mounts; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') VINTF fragment mounted before HAL startup"
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') ERROR: VINTF fragment bind mount failed"
    exit 1
fi

# Xiaomi ships the AOSP external-camera implementation without its optional
# config file and assigns an exclusive resource cost to every external device.
# This validated copy reads our module-owned config and gives the software-only
# loopback a cost of 1, allowing it to coexist with the physical input camera.
# The bind mount is reversible and lasts for this boot only.
if ! grep -q " $EXT_IMPL_TARGET " /proc/mounts; then
    chcon u:object_r:vendor_file:s0 "$EXT_IMPL_SOURCE" 2>/dev/null
    mount --bind "$EXT_IMPL_SOURCE" "$EXT_IMPL_TARGET"
fi

if grep -q " $EXT_IMPL_TARGET " /proc/mounts; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') external-camera config shim mounted"
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') ERROR: external-camera config shim failed"
    exit 1
fi
