#!/system/bin/sh

for pid_file in /data/local/tmp/android-vcam-provider-supervisor.pid \
                /data/local/tmp/android-vcam-provider.pid \
                /data/local/tmp/android-vcam-producer.pid \
                /data/local/tmp/android-vcam-return.pid \
                /data/local/tmp/android-vcam-sender.pid; do
    if [ -r "$pid_file" ]; then
        pid=$(cat "$pid_file")
        kill "$pid" 2>/dev/null
        rm -f "$pid_file"
    fi
done

sleep 1
rmmod v4l2loopback 2>/dev/null
rm -f /data/local/tmp/android-vcam.log \
      /data/local/tmp/android-vcam-return.mjpg \
      /data/local/tmp/android-vcam-return-ffmpeg.log \
      /data/local/tmp/android-vcam-return-ffmpeg.log.current \
      /data/local/tmp/android-vcam-sender-ffmpeg.log \
      /data/local/tmp/android-vcam-sender-ffmpeg.log.current \
      /data/local/tmp/vcam.xml
