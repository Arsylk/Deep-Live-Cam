# Android virtual-camera processor client v0.4.5

This is the single-camera, physical-provider-safe build for the Apollo phone.
The selected route processes the Arch webcam and returns it to the phone's SRT
listener on port `10001`. The companion app's physical Camera2 owner and phone
uplink stay stopped in this mode.

## Camera topology

- The module creates exactly one loopback node: `/dev/video20`.
- The AOSP external provider exposes that node as external Camera2 ID `120`.
- `/dev/video0`, `/dev/video1`, and every Qualcomm camera node remain unchanged.
- Android init remains the sole owner of the Qualcomm physical-camera provider.
- The module never issues `stop` or `kill` against the Qualcomm provider and
  never mounts over a physical camera device node.

The installable ZIP uses the validated provider, producer, fallback image, and
`v4l2loopback.ko` from v0.3.0. Apollo does not project module files into its
separate read-only vendor partition, so the early hook retains v0.3.0's two
known-good vendor-file binds: the combined IR/external VINTF fragment and the
external-camera implementation. Neither bind touches camera device nodes or
the Qualcomm provider.

At installation only, `customize.sh` repairs the one known stale state from the
experimental dual build: if `persist.vendor.camera.disable` is exactly `1`, it
is changed to `0` before reboot. Other values and all other properties are left
untouched; there is no recurring property override.

## Transport isolation

- `PHONE_CAPTURE_ENABLED=0` keeps `bridge-capture.sh`, `bridge-sender.sh`, and
  the merged app's physical Camera2 owner stopped for the processed-webcam
  route. Setting it to `1` explicitly restores phone-camera input mode.
- `bridge-return.sh` receives processed frames and publishes a decoded-frame
  heartbeat while copying the optional AAC track to a private A/V feed.
- `bridge-audio.sh` decodes that AAC track to 48 kHz mono PCM on localhost
  UDP 10025. The scoped Xposed module consumes it only while the redirected
  front camera is active; it is never played through the phone speaker.
- `bridge-output-selector.sh` is the only writer to Camera2 ID 120. It selects
  processed video only while frames advance. With phone capture disabled, a
  return outage shows the module fallback frame without changing camera
  identity or format; phone-input mode may instead fall back to its raw feed.

Camera2 ID 120 remains 1280×720 at 30 FPS across return-stream loss and
recovery. The v0.4.5 APK preview selects ID 120 first and falls back only to
another external camera, never to a physical phone camera.
