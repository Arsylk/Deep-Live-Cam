# Android virtual-camera slot client v0.3.1

The phone is Windows slot 0: physical Camera2 frames travel to UDP 10000 and
the processed return arrives on UDP 10001. Camera2 ID 120 stays registered at
1280×720/30 throughout selection changes and network failures.

The stack is deliberately split into four workers:

- `bridge-capture.sh` is the only client of the app's hardware H.264 socket and
  creates two loopback-only encoded copies.
- `bridge-sender.sh` retries slot-0 SRT independently. Being unselected cannot
  interrupt local camera output.
- `bridge-return.sh` receives processed frames into a loopback feed and writes
  an FFmpeg progress heartbeat.
- `bridge-output-selector.sh` is the sole MJPEG FIFO writer. It chooses the
  processed feed while the heartbeat is fresh and the phone's raw feed
  otherwise.

The existing `vcam_mjpeg_fifo`, `/dev/video20`, provider supervisor, and Camera2
ID 120 remain alive while the selector changes sources. The OS therefore sees
one camera identity and one format, not a raw camera and a processed camera.

Arch no longer receives a phone-specific relay. Windows publishes the selected
processed stream once on multicast UDP 10010, which the Arch stable camera and
native manager can consume without coupling the Android and Arch stacks.
