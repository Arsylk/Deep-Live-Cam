#!/system/bin/sh

MODDIR=${0%/*}
. "$MODDIR/bridge.conf"

FFMPEG="$TERMUX_PREFIX/bin/ffmpeg"
export LD_LIBRARY_PATH="$TERMUX_PREFIX/lib"
DETAIL_LOG=/data/local/tmp/android-vcam-sender-ffmpeg.log
ATTEMPT_LOG=${DETAIL_LOG}.current
retry_delay=1

# This worker may fail/retry forever while slot 0 is unselected. The separate
# capture fanout and local Camera2 fallback never stop with it.
while true; do
    started_at=$(date +%s)
    "$FFMPEG" \
        -hide_banner -loglevel warning -nostdin \
        -fflags nobuffer -flags low_delay \
        -analyzeduration 0 -probesize 65536 \
        -f mpegts -i "udp://127.0.0.1:$ANDROID_SENDER_FEED_PORT?fifo_size=1000000&overrun_nonfatal=1&reuse=1" \
        -map 0:v:0 -an -c:v copy \
        -mpegts_flags resend_headers -muxdelay 0 -muxpreload 0 \
        -f mpegts \
        "srt://$WINDOWS_HOST:$WINDOWS_INPUT_PORT?mode=caller&transtype=live&latency=$SRT_LATENCY_US&connect_timeout=3000&timeout=5000000&tlpktdrop=1&pkt_size=1316" \
        >/dev/null 2>"$ATTEMPT_LOG"
    status=$?
    mv -f "$ATTEMPT_LOG" "$DETAIL_LOG"
    runtime=$(($(date +%s) - started_at))
    echo "$(date '+%Y-%m-%d %H:%M:%S') sender exited status=$status after ${runtime}s; retrying in ${retry_delay}s (details: $DETAIL_LOG)"
    sleep "$retry_delay"
    if [ "$runtime" -ge 30 ]; then
        retry_delay=1
    elif [ "$retry_delay" -lt 10 ]; then
        retry_delay=$((retry_delay * 2))
        [ "$retry_delay" -gt 10 ] && retry_delay=10
    fi
done
